from django.contrib import admin
from .models import (
    Category,
    Product,
    ProductImage,
    Size,
    Color,
    ProductVariation,
    Cart,
    CartItem,
    Order,
    OrderItem
)

# ---------------------------
# Inline Models
# ---------------------------

class ProductImageInline(admin.TabularInline):
    model = ProductImage
    extra = 1


class ProductVariationInline(admin.TabularInline):
    model = ProductVariation
    extra = 1


class CartItemInline(admin.TabularInline):
    model = CartItem
    extra = 0


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0


# ---------------------------
# Category Admin
# ---------------------------

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_at')
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ('name',)


# ---------------------------
# Product Admin
# ---------------------------

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'stock', 'is_available')
    list_filter = ('category', 'is_available')
    search_fields = ('name', 'description')
    prepopulated_fields = {'slug': ('name',)}
    inlines = [ProductImageInline, ProductVariationInline]


# ---------------------------
# Size Admin
# ---------------------------

@admin.register(Size)
class SizeAdmin(admin.ModelAdmin):
    list_display = ('name',)


# ---------------------------
# Color Admin
# ---------------------------

@admin.register(Color)
class ColorAdmin(admin.ModelAdmin):
    list_display = ('name',)


# ---------------------------
# Cart Admin
# ---------------------------

@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at')
    inlines = [CartItemInline]


# ---------------------------
# Order Admin
# ---------------------------

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('order_number', 'user', 'total_price', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('order_number', 'user__username')
    inlines = [OrderItemInline]


# ---------------------------
# Order Item Admin
# ---------------------------

@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'product_variation', 'quantity', 'price')
