from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.home, name='home'),
    path('product/<slug:slug>/', views.product_detail, name='product_detail'),

    path('add-to-cart/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart, name='cart'),
    path('remove-cart-item/<int:item_id>/', views.remove_cart_item, name='remove_cart_item'),

    path('checkout/', views.checkout, name='checkout'),
    path('place-order/', views.place_order, name='place_order'),
    path('update-cart/<int:item_id>/', views.update_cart, name='update_cart'),
path('remove-cart-item/<int:item_id>/', views.remove_cart_item, name='remove_cart_item'),
path('order-success/<str:order_number>/', views.order_success, name='order_success'),
    path('orders/', views.my_orders, name='my_orders'),
        path(
        'login/',
        auth_views.LoginView.as_view(
            template_name='eclothesapp/login.html'
        ),
        name='login'
    ),
path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("signup/", views.signup, name="signup"),


]
