from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.crypto import get_random_string
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

from .models import (
    Category,
    Product,
    ProductVariation,
    Cart,
    CartItem,
    Order,
    OrderItem
)

# -------------------------
# Home / Product List
# -------------------------
def home(request):
    products = Product.objects.filter(is_available=True)

    product_data = []
    for product in products:
        variation = ProductVariation.objects.filter(
            product=product,
            stock__gt=0
        ).first()

        product_data.append({
            "product": product,
            "variation": variation,
        })

    context = {
        "product_data": product_data
    }
    return render(request, "eclothesapp/home.html", context)

# -------------------------
# Product Detail
# -------------------------
def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    variations = ProductVariation.objects.filter(product=product)

    context = {
        'product': product,
        'variations': variations,
    }
    return render(request, 'eclothesapp/product_detail.html', context)


# -------------------------
# Get or Create Cart
# -------------------------
def _get_cart(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    return cart


# -------------------------
# Add to Cart
# -------------------------

@login_required
def add_to_cart(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request"}, status=400)

    variation_id = request.POST.get("variation_id")

    if not variation_id:
        return JsonResponse({"error": "Invalid variation"}, status=400)

    variation = get_object_or_404(ProductVariation, id=variation_id)

    if variation.stock <= 0:
        return JsonResponse({"error": "Out of stock"}, status=400)

    cart, _ = Cart.objects.get_or_create(user=request.user)

    cart_item, created = CartItem.objects.get_or_create(
        cart=cart,
        product_variation=variation
    )

    if not created:
        cart_item.quantity += 1
    else:
        cart_item.quantity = 1

    cart_item.save()

    cart_count = cart.items.count()

    return JsonResponse({
        "success": True,
        "cart_count": cart_count
    })

# -------------------------
# View Cart
# -------------------------
@login_required
def cart(request):
    cart = _get_cart(request)
    items = cart.items.select_related('product_variation__product')

    total = sum(
        item.product_variation.product.price * item.quantity
        for item in items
    )

    context = {
        'cart': cart,
        'items': items,
        'total': total,
    }
    return render(request, 'eclothesapp/cart.html', context)


# -------------------------
# Update Cart Item
# -------------------------
@login_required
def update_cart(request, item_id):
    cart_item = get_object_or_404(
        CartItem,
        id=item_id,
        cart__user=request.user
    )

    if request.method == "POST":
        quantity = int(request.POST.get('quantity', 1))
    else:
        quantity = int(request.GET.get('qty', cart_item.quantity))

    if quantity > 0:
        cart_item.quantity = quantity
        cart_item.save()
    else:
        cart_item.delete()

    return redirect('cart')

# -------------------------
# Remove Cart Item
# -------------------------
@login_required
def remove_cart_item(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    cart_item.delete()
    messages.success(request, "Item removed from cart")
    return redirect('cart')


# -------------------------
# Checkout Page
# -------------------------
@login_required
def checkout(request):
    cart = _get_cart(request)
    items = cart.items.select_related('product_variation__product')

    if not items.exists():
        messages.warning(request, "Your cart is empty")
        return redirect('home')

    total = sum(
        item.product_variation.product.price * item.quantity
        for item in items
    )

    context = {
        'cart': cart,
        'items': items,
        'total': total,
    }
    return render(request, 'eclothesapp/checkout.html', context)


# -------------------------
# Place Order
# -------------------------
@login_required
def place_order(request):
    if request.method != "POST":
        return redirect('checkout')

    cart = _get_cart(request)
    items = cart.items.select_related('product_variation__product')

    if not items.exists():
        messages.error(request, "Your cart is empty")
        return redirect('cart')

    total = 0
    for item in items:
        total += item.product_variation.product.price * item.quantity

        # Stock validation
        if item.quantity > item.product_variation.stock:
            messages.error(
                request,
                f"Not enough stock for {item.product_variation.product.name}"
            )
            return redirect('cart')

    # Create Order
    order = Order.objects.create(
        user=request.user,
        order_number=get_random_string(10).upper(),
        total_price=total
    )

    # Create Order Items
    for item in items:
        OrderItem.objects.create(
            order=order,
            product_variation=item.product_variation,
            price=item.product_variation.product.price,
            quantity=item.quantity
        )

        # Reduce stock
        item.product_variation.stock -= item.quantity
        item.product_variation.save()

    # Clear cart
    items.delete()

    messages.success(request, "Order placed successfully!")
    return redirect('order_success', order_number=order.order_number)

@login_required
def order_success(request, order_number):
    order = get_object_or_404(
        Order,
        order_number=order_number,
        user=request.user
    )
    return render(request, 'eclothesapp/order_success.html', {
        'order': order
    })

@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'eclothesapp/my_orders.html', {
        'orders': orders
    })




def signup(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # auto login after signup
            return redirect("home")
    else:
        form = UserCreationForm()

    return render(request, "registration/signup.html", {"form": form})

